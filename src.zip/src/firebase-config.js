export default{
    apiKey: "AIzaSyB5LmWbKG7eZY8PK5ihObPUuLClZqtAuzU",
    authDomain: "javebooks.firebaseapp.com",
    projectId: "javebooks",
    storageBucket: "javebooks.appspot.com",
    messagingSenderId: "866060458717",
    appId: "1:866060458717:web:6c94378645585d4def9934"
}