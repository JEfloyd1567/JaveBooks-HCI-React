/*class Book {
  constructor(name, author, pages, price, stock, genre) {
    this.name = name;
    this.author = author;
    this.pages = pages;
    this.price = price;
    this.stock = stock;
    this.genre = genre;
  }
}

const book = new Book();*/ 
export const data = [{
    name: 'Libro 1',
    author: '',
    pages: 0,
    price: 0,
    stock: 0,
    genre: ''
  }, {
    name: 'Libro 2',
    author: '',
    pages: 0,
    price: 0,
    stock: 0,
    genre: ''
  }, {
    name: 'Libro 3',
    author: '',
    pages: 0,
    price: 0,
    stock: 0,
    genre: ''
}];

/*serverData.forEach(data => {
  new Book(data.name, data.author, data.price);
});
const books = [
  new Book(),
  new Book(),
  new Book(),
];*/