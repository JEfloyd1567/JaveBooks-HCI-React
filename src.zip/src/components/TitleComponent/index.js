import TitleComponent from './TitleComponent';
export default TitleComponent;